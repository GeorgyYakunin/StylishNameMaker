package com.Example.stylishnamemaker;

public class ScalingUtilities {

    public enum ScalingLogic {
        CROP,
        FIT
    }
}
